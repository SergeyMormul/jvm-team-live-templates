#if (${PACKAGE_NAME} && $PACKAGE_NAME != "" )package ${PACKAGE_NAME}
#end

import org.springframework.data.mongodb.repository.MongoRepository

/**
 * Talks to {@link ${COLLECTION_NAME}} collection in MongoDB.
 */
interface ${COLLECTION_NAME}Repository extends MongoRepository<${COLLECTION_NAME}, String>, ${COLLECTION_NAME}RepositoryExtension { }
