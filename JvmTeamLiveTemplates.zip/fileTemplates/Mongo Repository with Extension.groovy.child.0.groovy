#if (${PACKAGE_NAME} && $PACKAGE_NAME != "" )package ${PACKAGE_NAME}
#end

import com.transparent.molde.repository.BaseRepository
import groovy.transform.InheritConstructors

/**
 * Provides additional custom repository behavior for the {@link ${COLLECTION_NAME}Repository}.
 */
@InheritConstructors
class ${COLLECTION_NAME}RepositoryImpl extends BaseRepository implements ${COLLECTION_NAME}RepositoryExtension {

}
