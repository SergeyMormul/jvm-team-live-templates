#if (${PACKAGE_NAME} && $PACKAGE_NAME != "" )package ${PACKAGE_NAME}
#end

#parse("File Header.groovy")
@interface ${NAME} {

}