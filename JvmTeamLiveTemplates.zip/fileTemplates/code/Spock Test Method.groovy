def '${NAME}'() {
${BODY}
}