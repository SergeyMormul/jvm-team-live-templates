import static org.junit.jupiter.api.Assertions.assertEquals;
#parse("File Header.java")
class ${NAME} {
  ${BODY}
}