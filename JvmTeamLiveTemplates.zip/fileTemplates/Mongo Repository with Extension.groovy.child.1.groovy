#if (${PACKAGE_NAME} && $PACKAGE_NAME != "" )package ${PACKAGE_NAME}
#end

/**
 * Provides custom repository functionality, specifically for the {@link ${COLLECTION_NAME}Repository}.
 */
interface ${COLLECTION_NAME}RepositoryExtension {


}
